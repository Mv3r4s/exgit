package saucedemo;

import java.util.Random;

public class Mock {

    public static void main(String[] args) {
        System.out.println(new Random().nextInt(1, 22));
//        System.out.println(new Random().nextInt(1, 9));
    }
}
