package tests;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Red {
    public static void main(String[] args) throws IOException {

    }
}
